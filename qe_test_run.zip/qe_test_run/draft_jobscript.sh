#!/bin/bash
#SBATCH --job-name=Change_ME 
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1
#SBATCH --time=0-00:10:00 
#SBATCH --mail-type=begin,end,fail,requeue 
#SBATCH --export=all 
#SBATCH --out=Foundry-%j.out 

# OPTIONS
# -c, --cpus-per-task=<count>	Number of CPUs required per task
# -n, --ntasks=<count>	Number of tasks to be launched
# -a, --array=<index>	Job array specification (sbatch only)
# -J, --job-name=<name>	Job name
# -N, --nodes=<count>	Number of nodes required for the job
# -p, --partition=<names>	Partition in which to run the job
# -t, --time=<time>	Limit for job run time

# Activate python ---------------------------------------------------
module load anaconda
conda init

# Activate Quantum Espresso -----------------------------------------
module load quantum-espresso/6.5

# Download PSUEDOPOTENTIAL files:
# wget https://www.physics.rutgers.edu/gbrv/all_pbe_UPF_v1.5.tar.gz
# tar -xvf all_pbe_UPF_v1.5.tar.gz
# Take note of the path to the PSUEDOPOTENTIAL files
export ESPRESSO_PSEUDO=$(realpath ~/apps/QuantumEspresso/PSEUDO/gbrv/pbe/) # CHANGE THIS to the PATH
export ESPRESSO_TMPDIR='./TMPDIR'
export ESPRESSO_COMMAND="srun pw.x -in PREFIX.pwi > PREFIX.pwo"
export PYTHONUNBUFFERED=1

# Print job information --------------------------------------------

echo "SLURM_JOB_ID" $SLURM_JOB_ID
echo "SLURM_ARRAY_JOB_ID" $SLURM_ARRAY_JOB_ID
echo "SLURM_ARRAY_TASK_ID" $SLURM_ARRAY_TASK_ID
echo "SLURM_ARRAY_TASK_COUNT" $SLURM_ARRAY_TASK_COUNT
echo "SLURM_ARRAY_TASK_MAX" $SLURM_ARRAY_TASK_MAX
echo "SLURM_ARRAY_TASK_MIN" $SLURM_ARRAY_TASK_MIN

ulimit -s unlimited

# Run the job -------------------------------------------------------

echo "========= Job started  at `date` =========="
python  run_all.py

echo "========= Job finished at `date` =========="

