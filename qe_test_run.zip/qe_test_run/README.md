# Quantum espresso test files

1. Water molecule in a box
2. Si crystal
3. Water molecule ionic optimization
4. Si crystal ionic+lattice optimization