import os
import sys
from pathlib import Path
import subprocess
import shutil
import glob

ESPRESSO_COMMAND = os.environ["ESPRESSO_COMMAND"]
template_prefix = "PREFIX"
maindir = Path.cwd()


filenames = [x.replace(".pwi", "") for x in glob.glob("*.pwi")]

os.makedirs("run_files", exist_ok=True)
os.chdir("run_files")
run_dir = Path.cwd()


for f in filenames:
    print(f"Running {f}...")
    os.makedirs(f, exist_ok=True)
    os.chdir(run_dir.joinpath(f))
    shutil.copy(maindir.joinpath(f"{f}.pwi"), "./")

    subprocess.run(ESPRESSO_COMMAND.replace("PREFIX", f), shell=True, check=True)

    shutil.rmtree(os.environ["ESPRESSO_TMPDIR"])

    os.chdir(run_dir)
