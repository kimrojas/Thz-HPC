#!/bin/sh
#SBATCH -p i8cpu
#SBATCH -N 1
#SBATCH -n 64
#SBATCH -c 1
#SBATCH -t 00:30:00
#SBATCH -J calc
#SBATCH -a 1

# OPTIONS
# -c, --cpus-per-task=<count>	Number of CPUs required per task
# -n, --ntasks=<count>	Number of tasks to be launched
# -a, --array=<index>	Job array specification (sbatch only)
# -J, --job-name=<name>	Job name
# -N, --nodes=<count>	Number of nodes required for the job
# -p, --partition=<names>	Partition in which to run the job
# -t, --time=<time>	Limit for job run time

# Activate python ---------------------------------------------------
source /home/k0107/k010725/apps/mambaforge/initialize_conda.sh
mamba activate qe

# Activate Quantum Espresso -----------------------------------------
export PATH=$(realpath ~/apps/QuantumEspresso/CODE/q-e-qe-7.2/bin):$PATH
export ESPRESSO_PSEUDO=$(realpath ~/apps/QuantumEspresso/PSEUDO/gbrv/pbe/)
export ESPRESSO_TMPDIR='./TMPDIR'
export ESPRESSO_COMMAND="srun pw.x -in PREFIX.pwi > PREFIX.pwo"
export PYTHONUNBUFFERED=1

# Print job information --------------------------------------------

echo "SLURM_JOB_ID" $SLURM_JOB_ID
echo "SLURM_ARRAY_JOB_ID" $SLURM_ARRAY_JOB_ID
echo "SLURM_ARRAY_TASK_ID" $SLURM_ARRAY_TASK_ID
echo "SLURM_ARRAY_TASK_COUNT" $SLURM_ARRAY_TASK_COUNT
echo "SLURM_ARRAY_TASK_MAX" $SLURM_ARRAY_TASK_MAX
echo "SLURM_ARRAY_TASK_MIN" $SLURM_ARRAY_TASK_MIN

ulimit -s unlimited

# Run the job -------------------------------------------------------

echo "========= Job started  at `date` =========="
python  run_all.py



echo "========= Job finished at `date` =========="

